# Website-Animals_in_Malaysia

Coursework project on developing a website about animals in Malaysia.

Copy and paste url below to your browser 

https://wyeehooi.github.io/Website-Animals_in_Malaysia/FancyAnimals.html

Credit: PL Yew | HZ Lee | myself
 
Reference for Login and Sign Up page: https://github.com/daveh/php-signup-login.git 
