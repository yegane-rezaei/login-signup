images for protected animals in malaysia
